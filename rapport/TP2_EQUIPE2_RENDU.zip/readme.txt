Ce projet utilise 2 librairies :
- junit 4.12
- mockito 2.23.0

Pour compiler et lancer le projet, utilisez maven et un IDE.
Les dependances seront ainsi gerees automatiquement, renseignees dans le fichier pom.xml.
